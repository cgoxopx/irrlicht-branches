This branch is used for development of the OpenGL-ES drivers for Irrlicht.
There will be drivers for ogl-es 1.x and 2.x at some time, but we'll start
with 1.x first. Both drivers will be separate drivers, loosely based on the
OpenGL driver.
The branch is based on SVN/trunk and will be updated only very slowly. It's
not intended for regular use besides when working with ogl-es development.
